'use strict';

module.exports = {
  init: require('./src/init'),
  write: require('./src/write')
};
