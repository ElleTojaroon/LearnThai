'use strict';

function helloWorld2() {
    console.log('Hello world 7!');
}
