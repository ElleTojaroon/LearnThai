'use strict';

function helloWorld() {
    console.log('Hello world!');
}
