<template>
  <div>
    <head>
      <!-- <script src="https://use.fontawesome.com/4588f6f7b3.js"></script> -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Learn Thai</title>

      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="../static/css/bootstrap.css">
      <link rel="stylesheet" href="../static/css/custom.css">
    </head>

    <body id="app">
      <lt-navbar></lt-navbar>
    </body>
  </div>
</template>
