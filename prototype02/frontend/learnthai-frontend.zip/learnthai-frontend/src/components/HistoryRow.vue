<template>
  <div>
    <img src="../../static/images/icons/learnthai_icon.jpg" id="lt-navbar-icon">
  </div>
</template>
